package com.example.activities



import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class MyStateChangeActivity : AppCompatActivity() {

    // Called at the start of the full lifetime.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize Activity and inflate the UI.
        Log.d("MyStateChangeActivity", "onCreate()")
    }
    // Called after onCreate has finished, use to restore UI state
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d("MyStateChangeActivity", "onRestoreInstanceState")
    }

    override fun onRestart() {
        super.onRestart()

        Log.d("MyStateChangeActivity", "onRestart")
    }

    override fun onStart() {
        super.onStart()

        Log.d("MyStateChangeActivity", "onStart")
    }

    override fun onResume() {
        super.onResume()

        Log.d("MyStateChangeActivity", "onResume")
    }


    // Called at the end of the active lifetime.
    override fun onPause() {
        super.onPause()
        Log.d("MyStateChangeActivity", "onPause")
    }

    // Called at the end of the visible lifetime.
    override fun onStop() {
        super.onStop()
        Log.d("MyStateChangeActivity", "onStop")
    }

    // Sometimes called at the end of the full lifetime.
    override fun onDestroy() {

        super.onDestroy()
        Log.d("MyStateChangeActivity", "onDestroy")
    }
}